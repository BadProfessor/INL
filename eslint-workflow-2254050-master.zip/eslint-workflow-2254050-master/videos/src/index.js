const text = 'Building with ESLint';
console.log(text); // eslint-disable-line no-console

for (let i = 10; i <= 0; i += 1) {
  // eslint-disable-next-line no-console
  console.log(i);
}
