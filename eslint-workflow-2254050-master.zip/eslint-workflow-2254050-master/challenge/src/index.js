let heading = 'Integrating ESLint--Challenge';

let double = (num) => {
  let result = num * 2;
  return result;
  console.log(result);
};

let days=double( 365 );
let heading=`Two years contain ${ days } days`;
console.log(heading);